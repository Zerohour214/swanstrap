/*
 * Copyright (C) 2008 Martin Willi
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.  See <http://www.fsf.org/copyleft/gpl.txt>.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 */

#include "des_plugin.h"

#include <library.h>
#include "des_crypter.h"

typedef struct private_des_plugin_t private_des_plugin_t;

/**
 * private data of des_plugin
 */
struct private_des_plugin_t {

	/**
	 * public functions
	 */
	des_plugin_t public;
};

METHOD(plugin_t, get_name, char*,
	private_des_plugin_t *this)
{
	return "des";
}

METHOD(plugin_t, get_features, int,
	private_des_plugin_t *this, plugin_feature_t *features[])
{
	static plugin_feature_t f[] = {
		PLUGIN_REGISTER(CRYPTER, des_crypter_create),
			PLUGIN_PROVIDE(CRYPTER, ENCR_3DES, 24),
			PLUGIN_PROVIDE(CRYPTER, ENCR_DES, 8),
			PLUGIN_PROVIDE(CRYPTER, ENCR_DES_ECB, 8),
	};
	*features = f;
	return countof(f);
}

METHOD(plugin_t, destroy, void,
	private_des_plugin_t *this)
{
	free(this);
}

/*
 * see header file
 */
PLUGIN_DEFINE(des)
{
	private_des_plugin_t *this;

	INIT(this,
		.public = {
			.plugin = {
				.get_name = _get_name,
				.get_features = _get_features,
				.destroy = _destroy,
			},
		},
	);

	return &this->public.plugin;
}

